import React,{ useState, useEffect } from "react";
import ChatHead from "../chatbot-head";
import ChooseOption1 from "../select-options";
import ChatFooter from "../chatbot-footer";
import BotDialogues1 from "../bot-Dialogues";
import messageicon from "../../assets/icons/message-icon.svg";
import '../../assets/styles/global.scss';
import './index.css';
import axios from 'axios'
const MessageScreen = () => {
  // eslint-disable-next-line react-hooks/rules-of-hooks
  const [questions , setQuestions] = useState({});
useEffect(() => {
    const fetchQuestions = async () => {
      const baseUrl = 'http://stormy-sierra-19463.herokuapp.com'
      const apiVersion = 'api/v1'
      const entity = 'question'
      const endPoint = `${baseUrl}/${apiVersion}/${entity}/`
      console.log("in questions");
      try {
        console.log("in questions try");
        const response = await axios.get(endPoint);
        console.log("response", response.data.questions.childrens);
        setQuestions(response.data.questions.childrens);
        console.log("state", questions);
      } catch (e) {
          console.log(e);
      }
    }
    fetchQuestions()
  }, [axios, setQuestions])

  return (
    <div className="complete_bot second_screen_size">
      {questions.length>0 ? (
        <>
          <div className=" border border-blue-400 rounded-lg">
            <ChatHead />
            <div className="message_body" style={{height:"450px"}}>
            <div className="message-main sender">
                <div className="user-avatar"></div>
                    <div className="d-flex align-items-start comment">
                    <div className="comment_item">
                        <span className="comment_desc">Hellow Jinni!</span>
                    </div>
                    </div>
            </div>
            <div className="message-main">
                <div className="user-avatar"></div>
                    <div className="d-flex align-items-start comment">
                    <div className="comment_item">
                        <span className="comment_desc">Please let me know how can we assist you, we are her to guide you throughout the process</span>
                    </div>
                    </div>
            </div>
            <div className="message-main reciever">
                    <div className="d-flex align-items-start comment">
                    <div className="comment_item">
                        <span className="comment_desc">Hi!</span>
                    </div>
                    </div>
                <div className="user-avatar"></div>
            </div>
            <div className="message-main reciever">
                    <div className="d-flex align-items-start comment">
                    <div className="comment_item">
                        <span className="comment_desc">Thats too technical for me, do you have a explainer video which will help me?</span>
                    </div>
                    </div>
                <div className="user-avatar"></div>
            </div>
            </div>
            <ChatFooter />
          </div>
        </>
      ) : (
        ""
      )}
      <div className="chat_icon">
  <img onClick={() => setQuestions(!questions)} src={messageicon} alt="" />
</div>
    </div>
  );
};

export default MessageScreen;
