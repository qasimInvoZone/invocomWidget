
import React,{ useState, useEffect } from "react";
import {Link} from 'react-router-dom';
import ChatHead from "../chatbot-head";
import '../../assets/styles/global.scss';
import messageIcon from '../../assets/icons/message-icon.svg';
import axios from 'axios'

const chatBot = () => {
// eslint-disable-next-line react-hooks/rules-of-hooks
const [chat , setChat] = useState(true);
// eslint-disable-next-line react-hooks/rules-of-hooks
const [configObj , setconfigObj] = useState('');
// eslint-disable-next-line react-hooks/rules-of-hooks
useEffect(() => {
    setConfig();
},[setconfigObj]);

const setConfig = async () => {
    const baseUrl = 'http://stormy-sierra-19463.herokuapp.com'
const apiVersion = 'api/v1'
const entity = 'user'
const endPoint = `${baseUrl}/${apiVersion}/${entity}/config`
try {
    const response = await axios.get(endPoint)
    console.log("response", response.data.configObj)
    localStorage.setItem('backgroundColor', JSON.stringify(response.data.configObj.backgroundColor))
    localStorage.setItem('textColor', JSON.stringify(response.data.configObj.textColor))
    localStorage.setItem('chatVisibility', JSON.stringify(response.data.configObj.chatVisibility))
    localStorage.setItem('backgroundStatus', JSON.stringify(response.data.configObj.backgroundStatus))
    localStorage.setItem('message', JSON.stringify(response.data.configObj.message))
    console.log(response.status)
    if (response.status === 200) {
          console.log("setting sent")
    }
    } catch (e) {
        console.log(e);
    }
}

return(
        <div className="complete_bot first_secreen_size" >
<div className="" style={{position:"relative", top:"30px"}}>
    {chat? 

        <div className=" border rounded-lg align-bottom" style={{borderColor: `${JSON.parse(localStorage.getItem("backgroundColor"))}`,height:"550px"}}>
            <div className="header-wrapper" style={{backgroundColor: `${JSON.parse(localStorage.getItem("backgroundColor"))}`}}>
                <div className="text-lg font-semi-bold" style={{backgroundColor: `${JSON.parse(localStorage.getItem("backgroundColor"))}`}}>
                   <b>InvoCom</b>
                </div>
                <div className="text-sm">
                    What can i help learn more about?
                </div>
            </div>
           <div className="p-6" > 
            <h2 className="text-lg  font-semibold">{JSON.parse(localStorage.getItem("backgroundStatus"))}</h2>
            <h3 className="text-base  text-gray-400">{JSON.parse(localStorage.getItem("message"))}</h3>
            </div>

            <div className="mt-4 p-6" >
                <Link to="/secondscreen">
                <div className="First-options" style={{backgroundColor: `${JSON.parse(localStorage.getItem("backgroundColor"))}`}}>
                    <p className='First-option-text'>Hire a Tech Expert</p>
                </div>
                </Link>
                <div className="First-options" style={{backgroundColor: `${JSON.parse(localStorage.getItem("backgroundColor"))}`}}>
                    <p className='First-option-text'>Ask a Question</p>
                </div>
                <div className="First-options" style={{backgroundColor: `${JSON.parse(localStorage.getItem("backgroundColor"))}`}}>
                    <p className='First-option-text'>Learn About InvoZone</p>
                </div>
                <div className="First-options" style={{backgroundColor: `${JSON.parse(localStorage.getItem("backgroundColor"))}`}}>
                    <p className='First-option-text'>Can't find what you're looking for?</p>
                </div>
            </div>       
        </div>
   
     :
      ''
      }
    
</div>
<div className="chat_icon">
  <img onClick={() => setChat(!chat)} src={messageIcon} alt="" />
</div>
</div>
);
}

export default chatBot;